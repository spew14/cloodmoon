import{A as a}from"./CJghFkAr.js";a();
