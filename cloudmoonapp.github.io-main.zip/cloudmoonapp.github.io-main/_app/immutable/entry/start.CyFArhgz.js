import{a as r}from"../chunks/D8zcuini.js";import{A as t}from"../chunks/B88EbFpT.js";export{t as load_css,r as start};
